﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirstDB.Models
{
    public class Loai
    {
        [Key]
        public int MaLoai { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage ="Tối đa 50 kí tự")]
        public string TenLoai { get; set; }
        public string MoTa { get; set; }
    }
}
