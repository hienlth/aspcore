﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirstDB.Models
{
    public class KhachHang
    {
        [Key]
        [MaxLength(10)]
        public string MaKH { get; set; }
        [Required]
        [MaxLength(50)]
        public string HoTen { get; set; }
        public string DienThoai { get; set; }
        public string Email { get; set; }
    }
}
