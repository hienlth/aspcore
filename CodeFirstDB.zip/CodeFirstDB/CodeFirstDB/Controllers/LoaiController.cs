﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CodeFirstDB.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CodeFirstDB.Controllers
{
    public class LoaiController : Controller
    {
        MyDbContext db = new MyDbContext();
        public IActionResult Index()
        {
            return View(db.Loais.ToList());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loai = db.Loais
                .SingleOrDefault(m => m.MaLoai == id);
            if (loai == null)
            {
                return NotFound();
            }

            return View(loai);
        }

        // GET: Loai/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Loai/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind("MaLoai,TenLoai,MoTa")] Loai loai)
        {
            if (ModelState.IsValid)
            {
                db.Add(loai);
                db.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(loai);
        }

        // GET: Loai/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loai = db.Loais.SingleOrDefault(m => m.MaLoai == id);
            if (loai == null)
            {
                return NotFound();
            }
            return View(loai);
        }

        // POST: Loai/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, [Bind("MaLoai,TenLoai,MoTa")] Loai loai)
        {
            if (id != loai.MaLoai)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(loai);
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LoaiExists(loai.MaLoai))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(loai);
        }

        // GET: Loai/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loai = db.Loais
                .SingleOrDefault(m => m.MaLoai == id);
            if (loai == null)
            {
                return NotFound();
            }

            return View(loai);
        }

        // POST: Loai/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var loai = db.Loais.SingleOrDefault(m => m.MaLoai == id);
            db.Loais.Remove(loai);
            db.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private bool LoaiExists(int id)
        {
            return db.Loais.Any(e => e.MaLoai == id);
        }
    }
}