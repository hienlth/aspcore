﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CodeFirstDB.Models;

namespace CodeFirstDB.Controllers
{
    [Produces("application/json")]
    [Route("api/MyLoai")]
    public class MyLoaiController : Controller
    {
        MyDbContext _context = new MyDbContext();

        //public MyLoaiController(MyDbContext context)
        //{
        //    _context = context;
        //}

        // GET: api/MyLoai
        [HttpGet]
        public IEnumerable<Loai> GetLoais()
        {
            return _context.Loais;
        }

        // GET: api/MyLoai/5
        [HttpGet("{id}")]
        public ActionResult GetLoai([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var loai =  _context.Loais.SingleOrDefault(m => m.MaLoai == id);

            if (loai == null)
            {
                return NotFound();
            }

            return Ok(loai);
        }

        // PUT: api/MyLoai/5
        [HttpPut("{id}")]
        public ActionResult PutLoai([FromRoute] int id, [FromBody] Loai loai)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != loai.MaLoai)
            {
                return BadRequest();
            }

            _context.Entry(loai).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LoaiExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/MyLoai
        [HttpPost]
        public ActionResult PostLoai([FromBody] Loai loai)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.Loais.Add(loai);
            _context.SaveChanges();

            return CreatedAtAction("GetLoai", new { id = loai.MaLoai }, loai);
        }

        // DELETE: api/MyLoai/5
        [HttpDelete("{id}")]
        public ActionResult DeleteLoai([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var loai = _context.Loais.SingleOrDefault(m => m.MaLoai == id);
            if (loai == null)
            {
                return NotFound();
            }

            _context.Loais.Remove(loai);
            _context.SaveChanges();

            return Ok(loai);
        }

        private bool LoaiExists(int id)
        {
            return _context.Loais.Any(e => e.MaLoai == id);
        }
    }
}